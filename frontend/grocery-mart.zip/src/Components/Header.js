import React, { Component } from "react";
import { Link } from 'react-router-dom';
class Header extends Component {
    constructor(props) {
        super(props)
        this.state = {
            product_cart: [],
            photo: 'http://127.0.0.1:8000/storage/product/',
        }
    }
    componentDidUpdate() {
        // const todos = localStorage.getItem("product_details");
        // console.log("manisha", JSON.parse(todos));
        // this.setState({ product_cart: JSON.parse(todos) });
        // console.log("product_cart", this.state.product_cart);
    }
    render() {
        
        let pathname = window.location.pathname;
        return (
            <header id="site-header" className="fixed-top">
                <div className="container">
                    <nav className="navbar navbar-expand-lg navbar-light">
                        <button className="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false"
                            aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon fa icon-expand fa-bars"></span>
                            <span className="navbar-toggler-icon fa icon-close fa-times"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarScroll">
                            <ul className="navbar-nav mx-auto my-2 my-lg-0 navbar-nav-scroll">
                                <li className={`${pathname.match('/home') ? 'nav-item active' : 'nav-item'}`}>
                                    <Link to={"/home"} className="nav-link">Home</Link>
                                </li>
                                <li className="nav-item dropdown">
                                    <Link to={"/products"} className={`${pathname.match('/products') ? 'nav-link dropdown-toggle active' : 'nav-link dropdown-toggle'}`} id="navbarScrollingDropdown" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        Products <i className="fas fa-angle-down"></i>
                                    </Link>
                                    <ul className="dropdown-menu dropdown-menu-2" aria-labelledby="navbarScrollingDropdown">
                                        <div className="row">
                                            <div className="col-lg-4">
                                                <ul className="multi-column-dropdown">
                                                    <h6>Kitchen</h6>
                                                    <li><Link to={"/products"}>Meat & Seafood </Link></li>
                                                    <li><Link to={"/products"}>Snack Foods<span>New</span></Link></li>
                                                    <li><Link to={"/products"}>Oils, Vinegars</Link></li>
                                                    <li><Link to={"/products"}>Pasta & Noodles<span>New</span></Link></li>
                                                </ul>
                                            </div>
                                            <div className="col-lg-4 mt-lg-0 mt-4">
                                                <ul className="multi-column-dropdown">
                                                    <h6>Household</h6>
                                                    <li><Link to={"/products"}>Detergents</Link></li>
                                                    <li><Link to={"/products"}>Floor & Other Cleaners</Link></li>
                                                    <li><Link to={"/products"}>Pet Care <span>New</span></Link></li>
                                                    <li><Link to={"/products"}><i>Festive Decoratives</i></Link></li>
                                                </ul>
                                            </div>
                                            <div className="col-lg-4">
                                                <div className="w3ls_products_pos">
                                                    <h4 className="mb-4">30%<i>Off/-</i></h4>
                                                    <img src="assets/images/nav.png" alt="nav" className="img-fluid" />
                                                </div>
                                            </div>
                                        </div>
                                    </ul>
                                </li>
                                <li className='nav-item dropdown'>
                                    {/* <li className={`${pathname.match('/about-us')}` || `${pathname.match('/faq')}` || `${pathname.match('/contact-us')}` ? 'nav-item dropdown active' : 'nav-item dropdown'}> */}
                                    <Link to={"/"} className="nav-link dropdown-toggle" id="navbarScrollingDropdown" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        Cms <i className="fas fa-angle-down"></i>
                                    </Link>
                                    <ul className="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
                                        <li><Link to={"/about-us"} className={`${pathname.match('/about-us') ? 'dropdown-item active' : 'dropdown-item'}`}>About Us</Link></li>
                                        <li><Link to={"/faq"} className={`${pathname.match('/faq') ? 'dropdown-item active' : 'dropdown-item'}`}>Faq's</Link></li>
                                        <li><Link to={"/contact-us"} className={`${pathname.match('/contact-us') ? 'dropdown-item active' : 'dropdown-item'}`}>Contact Us</Link></li>
                                    </ul>
                                </li>
                                <li className={`${pathname.match('/blog') ? 'nav-item active' : 'nav-item'}`}>
                                    <Link to={"/blog"} className='nav-link'>Blog</Link>
                                </li>
                                {/* <li className='nav-item' style={{color:'#FFF'}}>
                                    No. of items
                                    <br />
                                    No. of items
                                </li> */}


                                <li className="nav-item dropdown">
                                    <Link to={"/products"} className={`${pathname.match('/products') ? 'nav-link dropdown-toggle active' : 'nav-link dropdown-toggle'}`} id="navbarScrollingDropdown" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        <i className="fas fa-shopping-bag"></i>
                                    </Link>
                                    <ul className="dropdown-menu dropdown-menu-2" aria-labelledby="navbarScrollingDropdown">
                                        <div className="row">
                                            <div className="col-lg-12">
                                                <ul className="multi-column-dropdown">
                                                    <div className="col-lg-12">
                                                        <table className="table table-primary table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th scope="col">Name</th>
                                                                    <th scope="col">Quality</th>
                                                                    <th scope="col">Total</th>
                                                                    <th scope="col">Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <th scope="row">Amul Wheat Atta</th>
                                                                    <td>5</td>
                                                                    <td>$ 2125.00</td>
                                                                    <td><span class="badge badge-primary badge-pill"><i className="fa fa-close"></i></span></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </ul>
                                            </div>
                                        </div>
                                    </ul>
                                </li>
                            </ul>
                        </div>

                        <div className="cont-ser-position">
                            <nav className="navigation-dark">
                                <div className="theme-switch-wrapper">
                                    <label className="theme-switch" htmlFor="checkbox">
                                        <input type="checkbox" id="checkbox" />
                                        <div className="mode-container">
                                            <i className="gg-sun" onClick={() => localStorage.setItem('theme', 'light')}></i>
                                            <i className="gg-moon" onClick={() => localStorage.setItem('theme', 'dark')}></i>
                                        </div>
                                    </label>
                                </div>
                            </nav>
                        </div>
                    </nav>
                </div>
            </header>
        )
    }
}

export default Header;
