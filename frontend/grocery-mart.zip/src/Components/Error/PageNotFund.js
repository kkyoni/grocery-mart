import React,{Component} from "react";
class PageNotFund extends Component{
    render() {
        return (
            <div>
                    <div className="pesan-eror">404</div>
            </div>
        )
    }
}

export default PageNotFund;